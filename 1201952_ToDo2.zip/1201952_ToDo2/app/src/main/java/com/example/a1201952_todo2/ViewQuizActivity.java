package com.example.a1201952_todo2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewQuizActivity extends AppCompatActivity {

    private Button backHomeBtn, srchQuizBtn;
    private ArrayList<Question> questions = new ArrayList<Question>();

    private TextView quizTitle;

    private DataBaseHelper dbHelper;

    private MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_quiz);

        // initialize buttons
        backHomeBtn = (Button) findViewById(R.id.back_home_btn);
        srchQuizBtn = (Button) findViewById(R.id.srch_quiz_btn);

        // get recycler view
        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        // initialize text views
        quizTitle = (TextView) findViewById(R.id.quiz_title_srch);

        // initialize db helper
        dbHelper = new DataBaseHelper(this);

        // listener for back to home btn
        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToHome();
            }
        });

        // listener for search buttons
        srchQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // search if the quiz exists
                int result = dbHelper.getQuizIdByTitle(quizTitle.getText().toString().trim());
                if(result != -1){
                    //Toast.makeText(ViewQuizActivity.this, "Quiz Found", Toast.LENGTH_SHORT).show();
                    // get all quiz questions
                    String Title= quizTitle.getText().toString().trim();
                    questions = dbHelper.getAllQuizQuestions(Title);
                    // show questions
                    if(!questions.isEmpty()){
 //                       Toast.makeText(ViewQuizActivity.this, "Qfdfsdfsfdsd", Toast.LENGTH_SHORT).show();
                        recyclerView.setLayoutManager(new LinearLayoutManager(ViewQuizActivity.this));
                        adapter = new MyAdapter(getApplicationContext(), questions, false);
                        recyclerView.setAdapter(adapter);
                        recyclerView.setVisibility(View.VISIBLE);
                    }

                } else{
                    Toast.makeText(ViewQuizActivity.this, "Quiz Does Not Exists", Toast.LENGTH_SHORT).show();
                    return;
                }

            }
        });

    }

    void backToHome(){
        Intent intent;
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}