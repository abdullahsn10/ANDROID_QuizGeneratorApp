package com.example.a1201952_todo2;

public class Quiz {
    // attributes
    private int id;
    private String title;

    public Quiz(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
    public int getId(){
        return this.id;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public void setId(int id){
        this.id = id;
    }

}
