package com.example.a1201952_todo2;

import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView questionText, optionOne, optionTwo, optionThree, correctOption;
    CheckBox checkBox;

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        questionText = itemView.findViewById(R.id.quesion_text_list);
        optionOne = itemView.findViewById(R.id.option_one_list);
        optionTwo = itemView.findViewById(R.id.option_two_list);
        optionThree = itemView.findViewById(R.id.option_three_list);
        correctOption = itemView.findViewById(R.id.correct_option_list);
        checkBox = itemView.findViewById(R.id.question_checkbox);
    }
}
