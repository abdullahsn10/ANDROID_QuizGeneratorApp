package com.example.a1201952_todo2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get the buttons
        Button addQuestionBtn = (Button) findViewById(R.id.addQuestion_btn);
        Button genQuizBtn = (Button) findViewById(R.id.genQuiz_btn);
        Button viewQuizBtn = (Button) findViewById(R.id.viewQuiz_btn);

        // set handler for each button
        addQuestionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewActivity("AddQuestion");
            }
        });

        genQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewActivity("GenerateQuiz");
            }
        });

        viewQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startNewActivity("ViewQuiz");
            }
        });

    }



    void startNewActivity(String activityName){
        Intent intent;
        if(activityName.equals("AddQuestion")){
            intent = new Intent(this, AddQuestionActivity.class);
        } else if(activityName.equals("GenerateQuiz")){
            intent = new Intent(this, GenerateQuizActivity.class);
        } else{
            intent = new Intent(this, ViewQuizActivity.class);
        }
        startActivity(intent);
    }
}