package com.example.a1201952_todo2;

public class QuizQuestion {
    // attributes
    private int quizId;
    private int questionId;

    // constructor
    public QuizQuestion(int quizId, int questionId){
        this.quizId = quizId;
        this.questionId = questionId;
    }

    public int getQuizId() {
        return quizId;
    }

    public void setQuizId(int quizId) {
        this.quizId = quizId;
    }

    public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(int questionId) {
        this.questionId = questionId;
    }
}
