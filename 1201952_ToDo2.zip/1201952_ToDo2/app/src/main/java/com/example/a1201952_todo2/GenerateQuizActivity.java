package com.example.a1201952_todo2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GenerateQuizActivity extends AppCompatActivity {

    // attributes
    private MyAdapter adapter;
    private Button showQuestionsBtn, genQuizBtn, backHomeBtn;
    private ArrayList<Question> questions = new ArrayList<Question>();
    private TextView quizTitle, quizQuestionsNumbers;
    private DataBaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_generate_quiz);

        // Recycler View of questions
        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        // get buttons
        showQuestionsBtn = (Button) findViewById(R.id.show_questions_btn);
        genQuizBtn = (Button) findViewById(R.id.gen_quiz_btn);
        backHomeBtn = (Button) findViewById(R.id.back_home_btn);

        // get text fields
        quizTitle = (TextView) findViewById(R.id.quiz_title);

        // initialize db helper
        dbHelper = new DataBaseHelper(this);

        // set listener on show questions button
        showQuestionsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // get all questions
                questions = dbHelper.getAllQuestions();
                // show questions in the recycler view
                if(!questions.isEmpty()){
                    recyclerView.setLayoutManager(new LinearLayoutManager(GenerateQuizActivity.this));
                    adapter = new MyAdapter(getApplicationContext(), questions, true);
                    recyclerView.setAdapter(adapter);
                    recyclerView.setVisibility(View.VISIBLE);
                    showQuestionsBtn.setVisibility(View.GONE);
                }

            }
        });

        // set handler for back to home btn
        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToHome();
            }
        });

        // set listener on generate quiz button
        genQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                generateQuiz();
            }
        });

    }



    void generateQuiz() {
        String title = quizTitle.getText().toString().trim();

        // Insert the quiz
        int quizId = (int) dbHelper.insertQuiz(new Quiz(title));
        if (quizId != -1) {
            // Quiz added successfully
            Toast.makeText(this, "Quiz Added Successfully", Toast.LENGTH_SHORT).show();

            // Get selected question IDs from the adapter
            ArrayList<Integer> selectedQuestionIds = adapter.getSelectedQuestionIds();

            // Loop through selected question IDs and add them to the quiz
            for (int questionId : selectedQuestionIds) {
                Question question = dbHelper.getQuestionById(questionId);
                if (question != null) {
                    // Add the question to the quiz
                    long result = dbHelper.addQuestionToQuiz(questionId, quizId);
                    if (result != -1) {
                        // Question added successfully
                        Toast.makeText(this, "Question " + questionId + " Added Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        // Failed to add question to the quiz
                        Toast.makeText(this, "Failed to Add Question " + questionId + " to Quiz", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Invalid question ID
                    Toast.makeText(this, "Invalid Question Number: " + questionId, Toast.LENGTH_SHORT).show();
                }
            }
            backToHome();
        } else {
            // Failed to add quiz
            Toast.makeText(this, "Failed to Add Quiz, Quiz Already Exists!!!", Toast.LENGTH_SHORT).show();
        }
    }


    void backToHome(){
        Intent intent;
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    }