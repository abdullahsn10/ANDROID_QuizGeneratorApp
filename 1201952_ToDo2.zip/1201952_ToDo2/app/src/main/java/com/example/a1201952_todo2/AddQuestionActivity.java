package com.example.a1201952_todo2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

public class AddQuestionActivity extends AppCompatActivity {
    private Button addQuestionBtn, backHomeBtn;
    private TextView questionText, optionOne, optionTwo, optionThree;
    private DataBaseHelper dbHelper;

    private Spinner optionSpinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_question);

        // add items to correct option spinner
        String[] options = { "1", "2", "3" };
        optionSpinner = (Spinner) findViewById(R.id.correct_option_spinner);
        ArrayAdapter<String> optArr = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item, options);
        optionSpinner.setAdapter(optArr);

        // initialize db helper
        dbHelper = new DataBaseHelper(this);

        // initialize buttons
        addQuestionBtn = (Button) findViewById(R.id.add_question_btn);
        backHomeBtn = (Button) findViewById(R.id.back_home_btn);

        // initialize text views
        questionText = (TextView) findViewById(R.id.question_text);
        optionOne = (TextView) findViewById(R.id.option_one);
        optionTwo = (TextView) findViewById(R.id.option_two);
        optionThree = (TextView) findViewById(R.id.option_three);


//        dbHelper.clearDatabase();


        // set handler for back to home btn
        backHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backToHome();
            }
        });

        // set handler for add question button
        addQuestionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // trigger add question method
                addQuestion();
            }
        });


    }


    // this method will back to the home activity
    void backToHome(){
        Intent intent;
        intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    // this method will validate fields and add the question to the db
    void addQuestion(){
        // Get the input values
        String text = questionText.getText().toString().trim();
        String option1 = optionOne.getText().toString().trim();
        String option2 = optionTwo.getText().toString().trim();
        String option3 = optionThree.getText().toString().trim();
        int correctOptionIndex = optionSpinner.getSelectedItemPosition();

        // validate input
        if (text.isEmpty() || option1.isEmpty() || option2.isEmpty() || option3.isEmpty()) {
            Toast.makeText(this, "All fields are required", Toast.LENGTH_SHORT).show();
            return;
        }

        // create Question Object
        Question newQuestion = new Question(text, new String[]{option1, option2, option3}, correctOptionIndex);

        // add the question to the database
        long result = dbHelper.insertQuestion(newQuestion);

        // Check if the insertion was successful
        if (result != -1) {
            Toast.makeText(this, "Question added successfully", Toast.LENGTH_SHORT).show();
            clearFields(); // Clear input fields
        } else {
            Toast.makeText(this, "Failed to add question", Toast.LENGTH_SHORT).show();
        }
    }

    // this method will reset everything in the activity
    void clearFields(){
        questionText.setText("");
        optionOne.setText("");
        optionTwo.setText("");
        optionThree.setText("");
        optionSpinner.setSelection(0);
    }
}

