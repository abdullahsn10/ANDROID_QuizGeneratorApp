package com.example.a1201952_todo2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DataBaseHelper extends SQLiteOpenHelper {
    // constant values
    private static final String DB_NAME = "todo_two_abdullah.db";
    private static final int DB_VERSION = 1;

    // SQL statements for creating relations (tables)
    private static final String CREATE_QUESTION_TABLE = "CREATE TABLE Question (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "text TEXT NOT NULL," +
            "option1 TEXT NOT NULL," +
            "option2 TEXT NOT NULL," +
            "option3 TEXT NOT NULL," +
            "correctOption INTEGER NOT NULL CHECK(correctOption >= 1 AND correctOption <= 3)" +
            ")";

    private static final String CREATE_QUIZ_TABLE = "CREATE TABLE Quiz (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "title TEXT UNIQUE NOT NULL" +
            ")";

    private static final String CREATE_QUIZ_QUESTION_TABLE = "CREATE TABLE QuizQuestions (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "quizId INTEGER NOT NULL," +
            "questionId INTEGER NOT NULL," +
            "FOREIGN KEY (quizId) REFERENCES Quiz(id)," +
            "FOREIGN KEY (questionId) REFERENCES Question(id)" +
            ")";
    // constructor
    public DataBaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create the three tables using SQL Statements
        db.execSQL(CREATE_QUESTION_TABLE);
        db.execSQL(CREATE_QUIZ_TABLE);
        db.execSQL(CREATE_QUIZ_QUESTION_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // needed if we need to upgrade the db
    }

    // insert question to db
    public long insertQuestion(Question question){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("TEXT", question.getqText());
        values.put("OPTION1", question.getqOptions()[0]);
        values.put("OPTION2", question.getqOptions()[1]);
        values.put("OPTION3", question.getqOptions()[2]);
        values.put("CORRECTOPTION", question.getCorrectOptionIdx() + 1);

        long result = db.insert("Question", null, values);
        db.close();
        return result;
    }

    // method to retrieve all questions from the database
    public ArrayList<Question> getAllQuestions() {
        ArrayList<Question> questionsList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // query to retrieve all rows from the Question table
        Cursor cursor = db.rawQuery("SELECT * FROM Question", null);

        //  retrieve each row
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String text = cursor.getString(1);
            String option1 = cursor.getString(2);
            String option2 = cursor.getString(3);
            String option3 = cursor.getString(4);
            int correctOption = cursor.getInt(5);
            questionsList.add(new Question(id, text, new String[]{option1, option2, option3}, correctOption -1));
        }
        // Close the cursor and database connection
        cursor.close();
        db.close();
        return questionsList;
    }

    // method to get question by id
    public Question getQuestionById(int id){
        Question resQuestion = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String idStr = Integer.toString(id);
        // query to retrieve the question
        Cursor cursor = db.rawQuery("SELECT * FROM Question WHERE id = " + idStr, null);
        if (cursor.moveToNext()){
            String text = cursor.getString(1);
            String option1 = cursor.getString(2);
            String option2 = cursor.getString(3);
            String option3 = cursor.getString(4);
            int correctOption = cursor.getInt(5);
            resQuestion = new Question(id, text, new String[]{option1, option2, option3}, correctOption - 1);
        }
        return resQuestion;
    }

    // method to insert new quiz
    public long insertQuiz(Quiz quiz){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("TITLE", quiz.getTitle());
        long result = db.insert("Quiz", null, values);
        db.close();
        return result;
    }

    // method to get the quiz id given title
    public int getQuizIdByTitle(String title){
        SQLiteDatabase db = this.getReadableDatabase();

        // Define the selection criteria
        String selection = "title = ?";
        String[] selectionArgs = {title};

        // Query to retrieve the quiz ID by title
        Cursor cursor = db.query("Quiz", null, selection, selectionArgs, null, null, null);

        int quizId = -1; // Default value if no matching quiz found
        if (cursor.moveToNext()){
            return cursor.getInt(0);
        }
        return -1;
    }

    // method to add question to quiz
    public long addQuestionToQuiz(int questionId, int quizId){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("QUIZID", quizId);
        values.put("QUESTIONID", questionId);
        long result = db.insert("QuizQuestions", null, values);
        db.close();
        return result;
    }

    public ArrayList<Question> getAllQuizQuestions(String quizTitle) {
        ArrayList<Question> questionsList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        String[] selectionArgs = { quizTitle };

        Cursor cursor =  db.rawQuery("SELECT Question.* " +
                "FROM Question " +
                "JOIN QuizQuestions ON Question.id = QuizQuestions.questionId " +
                "JOIN Quiz ON Quiz.id = QuizQuestions.quizId " +
                "WHERE Quiz.title = ?", selectionArgs);

        //  retrieve each row
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String text = cursor.getString(1);
            String option1 = cursor.getString(2);
            String option2 = cursor.getString(3);
            String option3 = cursor.getString(4);
            int correctOption = cursor.getInt(5);
            questionsList.add(new Question(id, text, new String[]{option1, option2, option3}, correctOption -1));
        }
        // Close the cursor and database connection
        cursor.close();
        db.close();
        return questionsList;
    }
    public ArrayList<Integer> getAllQuizzes(){
        ArrayList<Integer> qzz = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // query to retrieve all rows from the Question table
        Cursor cursor = db.rawQuery("SELECT * FROM QuizQuestions", null);

        //  retrieve each row
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            int quizId = cursor.getInt(1);
            int qsId = cursor.getInt(2);
            qzz.add(id);
            qzz.add(quizId);
            qzz.add(qsId);
        }
        // Close the cursor and database connection
        cursor.close();
        db.close();
        return qzz;
    }

    public void clearDatabase() {
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete all records from the Question table
        db.delete("Question", null, null);
        // Delete all records from the Quiz table
        db.delete("Quiz", null, null);
        // Delete all records from the QuizQuestions table
        db.delete("QuizQuestions", null, null);
        db.close();
    }



}
