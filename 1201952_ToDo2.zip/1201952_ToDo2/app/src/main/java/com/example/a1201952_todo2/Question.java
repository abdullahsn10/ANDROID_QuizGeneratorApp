package com.example.a1201952_todo2;

public class Question {
    // question attributes
    private int id;
    private String qText;
    private String[] qOptions;
    private int correctOptionIdx; // correct option index in the array of options

    // constructor
    public Question(String text, String[] options, int correctOptionIdx){
        this.qText = text;
        this.qOptions = options;
        this.correctOptionIdx = correctOptionIdx;
    }

    public Question(int id, String text, String[] options, int correctOptionIdx){
        this.id = id;
        this.qText = text;
        this.qOptions = options;
        this.correctOptionIdx = correctOptionIdx;
    }

    // getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getqText() {
        return qText;
    }

    public void setqText(String qText) {
        this.qText = qText;
    }

    public String[] getqOptions() {
        return qOptions;
    }

    public void setqOptions(String[] qOptions) {
        this.qOptions = qOptions;
    }

    public int getCorrectOptionIdx() {
        return correctOptionIdx;
    }

    public void setCorrectOptionIdx(int correctOptionIdx) {
        this.correctOptionIdx = correctOptionIdx;
    }
}
