package com.example.a1201952_todo2;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    private Context context;
    private ArrayList<Question> questions;
    private ArrayList<Integer> selectedQuestionIds; // Track selected question IDs
    private boolean showCheckBoxes; // Flag to control visibilty of checkboxes

    public MyAdapter(Context context, ArrayList<Question> questions, boolean showCheckBoxes) {
        this.context = context;
        this.questions = questions;
        this.selectedQuestionIds = new ArrayList<>();
        this.showCheckBoxes = showCheckBoxes;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.question_list, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final Question currentQuestion = questions.get(position);
        holder.questionText.setText(currentQuestion.getId() + ". " + currentQuestion.getqText());
        holder.optionOne.setText("Option 1: " + currentQuestion.getqOptions()[0]);
        holder.optionTwo.setText("Option 2: " + currentQuestion.getqOptions()[1]);
        holder.optionThree.setText("Option 3: " + currentQuestion.getqOptions()[2]);
        holder.correctOption.setText("Correct Option: " + (currentQuestion.getCorrectOptionIdx() + 1));
        // set the visibilty of checkboxes
        if(showCheckBoxes){
            holder.checkBox.setVisibility(View.VISIBLE);
        } else{
            holder.checkBox.setVisibility(View.INVISIBLE);
        }
        // Set the checkbox state based on selectedQuestionIds
        holder.checkBox.setChecked(selectedQuestionIds.contains(currentQuestion.getId()));

        // Set OnClickListener for checkbox
        holder.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toggle checkbox state
                if (holder.checkBox.isChecked()) {
                    selectedQuestionIds.add(currentQuestion.getId()); // Add question ID to selectedQuestionIds
                } else {
                    selectedQuestionIds.remove((Integer) currentQuestion.getId()); // Remove question ID from selectedQuestionIds
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return questions.size();
    }

    // Method to get the IDs of selected questions
    public ArrayList<Integer> getSelectedQuestionIds() {
        return selectedQuestionIds;
    }
}